#!/bin/sh

#//=======================================================================
#//
#// SAMPLE SOURCE CODE - SUBJECT TO THE TERMS OF SAMPLE CODE LICENSE AGREEMENT
#// http://software.intel.com/en-us/articles/intel-sample-source-code-license-agreement/
#//
#// Copyright 2009-2015 Intel Corporation
#//
#// THIS FILE IS PROVIDED "AS IS" WITH NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT
#// NOT LIMITED TO ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
#// PURPOSE, NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS.
#//
#//========================================================================

cd ../makefiles
gmake -f Makefile_reg_mm_malloc_64_opt_dgemm clean
gmake -f Makefile_reg_mm_malloc_64_opt_dgemm dgemm
gmake -f Makefile_reg_mm_malloc_8192_opt_dgemm clean
gmake -f Makefile_reg_mm_malloc_8192_opt_dgemm dgemm
gmake -f Makefile_reg_mmap_opt_dgemm clean
gmake -f Makefile_reg_mmap_opt_dgemm dgemm

cd ../scripts
echo "Started running ./reg_mm_malloc_64_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 $1"
./reg_mm_malloc_64_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 $1
echo "Finished running ./reg_mm_malloc_64_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 $1"

echo "Started running ./reg_mm_malloc_8192_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 $1"
./reg_mm_malloc_8192_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 $1
echo "Finished running ./reg_mm_malloc_8192_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 $1"

echo "Started running ./reg_mmap_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 2M $1"
./reg_mmap_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 2M $1
echo "Finished running ./reg_mmap_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 2M $1"
