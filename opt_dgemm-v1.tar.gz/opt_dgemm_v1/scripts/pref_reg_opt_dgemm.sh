#!/bin/sh

#//=======================================================================
#//
#// SAMPLE SOURCE CODE - SUBJECT TO THE TERMS OF SAMPLE CODE LICENSE AGREEMENT
#// http://software.intel.com/en-us/articles/intel-sample-source-code-license-agreement/
#//
#// Copyright 2009-2015 Intel Corporation
#//
#// THIS FILE IS PROVIDED "AS IS" WITH NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT
#// NOT LIMITED TO ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
#// PURPOSE, NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS.
#//
#//========================================================================

cd ../makefiles
L2=0
L1=1
gmake -f Makefile_pref_reg_mm_malloc_64_opt_dgemm L2=${L2} L1=${L1} clean
gmake -f Makefile_pref_reg_mm_malloc_64_opt_dgemm L2=${L2} L1=${L1} dgemm
gmake -f Makefile_pref_reg_mm_malloc_8192_opt_dgemm L2=${L2} L1=${L1} clean
gmake -f Makefile_pref_reg_mm_malloc_8192_opt_dgemm L2=${L2} L1=${L1} dgemm
gmake -f Makefile_pref_reg_mmap_opt_dgemm L2=${L2} L1=${L1} clean
gmake -f Makefile_pref_reg_mmap_opt_dgemm L2=${L2} L1=${L1} dgemm

cd ../scripts
echo "Started running ./pref_${L2}_${L1}_reg_mm_malloc_64_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 $1"
./pref_${L2}_${L1}_reg_mm_malloc_64_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 $1
echo "Finished running ./pref_${L2}_${L1}_reg_mm_malloc_64_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 $1"

echo "Started running ./pref_${L2}_${L1}_reg_mm_malloc_8192_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 $1"
./pref_${L2}_${L1}_reg_mm_malloc_8192_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 $1
echo "Finished running ./pref_${L2}_${L1}_reg_mm_malloc_8192_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 $1"

echo "Started running ./pref_${L2}_${L1}_reg_mmap_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 2M $1"
./pref_${L2}_${L1}_reg_mmap_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 2M $1
echo "Finished running ./pref_${L2}_${L1}_reg_mmap_opt_dgemm.sh 61 4 240 120 23040 dynamic 2 2M $1"
