#!/bin/sh

#//=======================================================================
#//
#// SAMPLE SOURCE CODE - SUBJECT TO THE TERMS OF SAMPLE CODE LICENSE AGREEMENT
#// http://software.intel.com/en-us/articles/intel-sample-source-code-license-agreement/
#//
#// Copyright 2009-2015 Intel Corporation
#//
#// THIS FILE IS PROVIDED "AS IS" WITH NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT
#// NOT LIMITED TO ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
#// PURPOSE, NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS.
#//
#//========================================================================

export PHI_OMP_NUM_THREADS=`expr $2 \* $1`
export OMP_NUM_THREADS=${PHI_OMP_NUM_THREADS}
export MKL_NUM_THREADS=${PHI_OMP_NUM_THREADS}
export LD_LIBRARY_PATH=${MIC_LD_LIBRARY_PATH}:${LD_LIBRARY_PATH}:.
export MIC_LD_LIBRARY_PATH=${MIC_LD_LIBRARY_PATH}:.
export KMP_STACKSIZE=16M
export MIC_STACKSIZE=16M
export PHI_KMP_PLACE_THREADS=$1c,$2t
export KMP_BLOCKTIME=0
export OMP_SCHEDULE=$6,$7

cd ../bin
ssh $8 "export PHI_OMP_NUM_THREADS=${PHI_OMP_NUM_THREADS}; export OMP_NUM_THREADS=${OMP_NUM_THREADS}; export MKL_NUM_THREADS=${MKL_NUM_THREADS}; export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}; export MIC_LD_LIBRARY_PATH=${MIC_LD_LIBRARY_PATH}; export KMP_STACKSIZE=${KMP_STACKSIZE}; export MIC_STACKSIZE=${MIC_STACKSIZE}; export PHI_KMP_PLACE_THREADS=${PHI_KMP_PLACE_THREADS}; ulimit -s unlimited; ${PWD}/reg_mm_malloc_8192_opt_dgemm.exe $1 $2 1 $3 $4 $5 > ${PWD}/../reports/reg_mm_malloc_8192_opt_dgemm_report.$1.$2.$3.$4.$5.$6.$7.$8 2>&1"
