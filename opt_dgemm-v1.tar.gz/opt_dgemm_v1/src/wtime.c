//=======================================================================
//
// SAMPLE SOURCE CODE - SUBJECT TO THE TERMS OF SAMPLE CODE LICENSE AGREEMENT
// http://software.intel.com/en-us/articles/intel-sample-source-code-license-agreement/
//
// Copyright 2009-2015 Intel Corporation
//
// THIS FILE IS PROVIDED "AS IS" WITH NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT
// NOT LIMITED TO ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS.
//
//========================================================================

/****************************************************************

Name:      wtime

Purpose:   returns wall clock time with a fixed reference point.

Arguments: None

Returns:   The wall clock time in seconds as a double is returned. 

Notes:     This function uses two structures defined in the UNIX
           system call, gettimeofday(2). The structure, "timeval" 
           is defined in the include file <sys/time.h> as:

                 struct timeval {
                     long tv_sec;
                     long tv_usec;
                 }

           where timeval.tv_sec is the seconds and timeval.tv_usec
           is the microseconds.  
 
History:   Written by Tim Mattson, Dec 1, 1988
           Modified by Rob van der Wijngaart, May 2006, to change
           default clock to the Unix system clock.

****************************************************************/

#if defined(_OPENMP)
  #include <omp.h>
#elif defined(MPI)
  #include "mpi.h"
#else
  #include <sys/time.h>
  #define  USEC_TO_SEC   1.0e-6    /* to convert microsecs to secs */
#define NULL 0
#endif

double wtime() {
  double time_seconds;

#if defined(_OPENMP)
  time_seconds = omp_get_wtime();

#elif defined(MPI)
  time_seconds = MPI_Wtime();

#else
  struct timeval  time_data; /* seconds since 0 GMT */
   
  gettimeofday(&time_data,NULL);
   
  time_seconds  = (double) time_data.tv_sec;
  time_seconds += (double) time_data.tv_usec * USEC_TO_SEC;
#endif

  return time_seconds;
}
